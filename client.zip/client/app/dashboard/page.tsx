'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { useLanguage } from '@/contexts/LanguageContext'
import { useAuth } from '@/hooks/useAuth'
import { canAccessDashboard } from '@/lib/auth-utils'
import Navbar from '@/components/Navbar'
import Footer from '@/components/Footer'
import UserList from '@/components/dashboard/UserList'
import RequestList from '@/components/dashboard/RequestList'
import MarketAnalysisList from '@/components/dashboard/MarketAnalysisList'
import VipDashboardPreviewList from '@/components/dashboard/VipDashboardPreviewList'

export default function DashboardPage() {
  const router = useRouter()
  const { t, isRTL } = useLanguage()
  const { isAuthenticated, isLoading, user, isAdmin } = useAuth()
  const [activeTab, setActiveTab] = useState<'users' | 'requests' | 'marketAnalysis' | 'vipPreviews'>('users')

  // Redirect to login if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      router.push('/login')
    }
  }, [isAuthenticated, isLoading, router])

  // Redirect if not admin (dashboard is admin-only)
  useEffect(() => {
    if (!isLoading && isAuthenticated && !canAccessDashboard(user)) {
      router.push('/')
    }
  }, [isLoading, isAuthenticated, user, router])

  // Show loading state while checking auth
  if (isLoading) {
    return (
      <main className="min-h-screen bg-primary-dark flex items-center justify-center">
        <div className="text-accent">Loading...</div>
      </main>
    )
  }

  // Don't render content if not authenticated or not admin (will redirect)
  if (!isAuthenticated || !canAccessDashboard(user)) {
    return null
  }

  return (
    <main className="min-h-screen bg-primary-dark">
      <Navbar />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl md:text-4xl font-bold text-base-white mb-2">
            {t('dashboard.title')}
          </h1>
          <p className="text-accent">
            {t('dashboard.subtitle')}
          </p>
        </div>

        {/* Tabs */}
        <div className={`flex ${isRTL ? 'space-x-reverse' : ''} space-x-4 mb-8 border-b border-accent border-opacity-20`}>
          <button
            onClick={() => setActiveTab('users')}
            className={`px-6 py-3 font-semibold transition-colors duration-200 ${
              activeTab === 'users'
                ? 'text-base-white border-b-2 border-accent'
                : 'text-accent hover:text-base-white'
            }`}
          >
            {t('dashboard.tabs.users')}
          </button>
          <button
            onClick={() => setActiveTab('requests')}
            className={`px-6 py-3 font-semibold transition-colors duration-200 ${
              activeTab === 'requests'
                ? 'text-base-white border-b-2 border-accent'
                : 'text-accent hover:text-base-white'
            }`}
          >
            {t('dashboard.tabs.requests')}
          </button>
          <button
            onClick={() => setActiveTab('marketAnalysis')}
            className={`px-6 py-3 font-semibold transition-colors duration-200 ${
              activeTab === 'marketAnalysis'
                ? 'text-base-white border-b-2 border-accent'
                : 'text-accent hover:text-base-white'
            }`}
          >
            {t('dashboard.tabs.marketAnalysis')}
          </button>
          <button
            onClick={() => setActiveTab('vipPreviews')}
            className={`px-6 py-3 font-semibold transition-colors duration-200 ${
              activeTab === 'vipPreviews'
                ? 'text-base-white border-b-2 border-accent'
                : 'text-accent hover:text-base-white'
            }`}
          >
            {t('dashboard.tabs.vipPreviews')}
          </button>
        </div>

        {/* Content */}
        <div>
          {activeTab === 'users' && <UserList />}
          {activeTab === 'requests' && <RequestList />}
          {activeTab === 'marketAnalysis' && <MarketAnalysisList />}
          {activeTab === 'vipPreviews' && <VipDashboardPreviewList />}
        </div>
      </div>
      <Footer />
    </main>
  )
}

