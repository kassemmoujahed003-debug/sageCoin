'use client'

import Navbar from '@/components/Navbar'
import Hero from '@/components/Hero'
import UserDashboard from '@/components/UserDashboard'
import CoursesSection from '@/components/CoursesSection'
import MarketAnalysisSection from '@/components/MarketAnalysisSection'
import dynamic from 'next/dynamic'

// Dynamically import VipTradingSection to avoid SSR hydration issues with framer-motion
const VipTradingSection = dynamic(() => import('@/components/VipTradingSection'), {
  ssr: false, // Disable SSR for this component to prevent hydration issues
  loading: () => <div className="h-[500vh]"></div> // Placeholder to maintain layout
})
import PublicCTASection from '@/components/PublicCTASection'
import Footer from '@/components/Footer'
import { useAuth } from '@/hooks/useAuth'
import { isMember } from '@/lib/auth-utils'

export default function Home() {
  const { isAuthenticated, user, isLoading } = useAuth()
  
  // Check if user is member (can access member/VIP content)
  const isMemberUser = isMember(user)
  
  const currentLeverage = user?.current_leverage || 100
  const currentLotSize = user?.current_lot_size || 0.1

  // Prevent hydration mismatch by waiting for auth to load
  if (isLoading) {
    return (
      <main className="min-h-screen bg-primary-dark flex items-center justify-center">
        <div className="text-accent">Loading...</div>
      </main>
    )
  }

  return (
    <main className="min-h-screen bg-primary-dark">
      <Navbar />
      
      {/* 1. Hero Section - "Who We Are" */}
      <Hero />
      
      {/* 2. Market Analysis Section (Public) */}
      <MarketAnalysisSection />
      
      {/* 3. User Dashboard (Conditional - Only if Logged In) */}
      {isAuthenticated && (
        <UserDashboard 
          currentLeverage={currentLeverage}
          currentLotSize={currentLotSize}
        />
      )}
          
      {/* 4. VIP Trading Section (Only visible to members) */}
      <VipTradingSection isMember={isMemberUser} />
            
      {/* 5. Courses Section (Only visible to members) */}
      <CoursesSection subscribedToCourses={isMemberUser} />
      
      {/* 6. Public CTA Section */}
      <PublicCTASection />
      
      {/* 6. Footer */}
      <Footer />
    </main>
  )
}

