'use client'

import React, { useRef, useState, useEffect, RefObject, useCallback } from 'react'
import { motion, useScroll, useTransform } from 'framer-motion'
import { useLanguage } from '@/contexts/LanguageContext'
import { getVipDashboardPreviews } from '@/services/vipDashboardPreviewService'
import { VipDashboardPreview } from '@/types/database'

interface VipTradingSectionProps {
  isMember: boolean
  joinedVip?: boolean // Legacy prop for backward compatibility
}

// Helper component for Diamond Look
const DiamondLayers = ({ heroOpacity, children }: { heroOpacity: any, children: React.ReactNode }) => (
  <div className="relative w-full h-full">
    <div className="absolute inset-0 rotate-45 bg-secondary-surface/90 border border-accent/30 rounded-[3rem] shadow-xl backdrop-blur-md flex items-center justify-center overflow-hidden transition-all duration-300">
      <div className="-rotate-45 w-full h-full flex items-center justify-center relative">
        {children}
      </div>
    </div>
    <motion.div
      style={{ opacity: heroOpacity }}
      className="absolute inset-0 rotate-45 bg-gradient-to-br from-secondary-surface via-primary-dark to-primary-dark border-2 border-accent rounded-[3rem] shadow-[0_0_60px_-10px_rgba(var(--accent-rgb),0.6)] flex items-center justify-center overflow-hidden z-10"
    >
      <div className="absolute inset-4 border border-accent/20 rounded-[2.5rem] pointer-events-none"></div>
      <div className="-rotate-45 w-full h-full flex items-center justify-center relative">
        {children}
      </div>
    </motion.div>
  </div>
)

// Inner component that uses useScroll - only rendered when container element is ready
function ScrollAnimatedContent({
  containerRef,
  t,
  isRTL
}: {
  containerRef: RefObject<HTMLElement>
  t: (key: string) => string
  isRTL: boolean
}) {
  // Now useScroll is only called when containerRef.current is guaranteed to exist
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start start", "end end"]
  })

  // --- 1. MAIN DIAMOND ANIMATION (VIP Access) ---
  const mainTop = useTransform(scrollYProgress, [0, 0.33, 0.66, 1], ["20%", "70%", "70%", "20%"])
  const mainLeft = useTransform(scrollYProgress, [0, 0.33, 0.66, 1], ["50%", "85%", "15%", "50%"])
  const mainScale = useTransform(scrollYProgress, [0, 0.33, 0.66, 1], [1.3, 0.6, 0.6, 1.3])
  const mainOpacity = useTransform(scrollYProgress, [0, 0.33, 0.66, 1], [1, 0.4, 0.4, 1])
  const mainZIndex = useTransform(scrollYProgress, [0, 0.15, 0.85, 1], [20, 10, 10, 20])
  const mainHeroOpacity = useTransform(scrollYProgress, [0, 0.15, 0.33, 0.66, 0.85, 1], [1, 1, 0, 0, 1, 1])

  // --- 2. LEFT DIAMOND ANIMATION (Signals) ---
  const leftTop = useTransform(scrollYProgress, [0, 0.33, 0.66, 1], ["70%", "20%", "70%", "70%"])
  const leftLeft = useTransform(scrollYProgress, [0, 0.33, 0.66, 1], ["15%", "50%", "85%", "15%"])
  const leftScale = useTransform(scrollYProgress, [0, 0.33, 0.66, 1], [0.6, 1.3, 0.6, 0.6])
  const leftOpacity = useTransform(scrollYProgress, [0, 0.33, 0.66, 1], [0.4, 1, 0.4, 0.4])
  const leftZIndex = useTransform(scrollYProgress, [0.15, 0.33, 0.5], [10, 20, 10])
  const leftHeroOpacity = useTransform(scrollYProgress, [0.15, 0.33, 0.5], [0, 1, 0])

  // --- 3. RIGHT DIAMOND ANIMATION (Analysis) ---
  const rightTop = useTransform(scrollYProgress, [0, 0.33, 0.66, 1], ["70%", "70%", "20%", "70%"])
  const rightLeft = useTransform(scrollYProgress, [0, 0.33, 0.66, 1], ["85%", "15%", "50%", "85%"])
  const rightScale = useTransform(scrollYProgress, [0, 0.33, 0.66, 1], [0.6, 0.6, 1.3, 0.6])
  const rightOpacity = useTransform(scrollYProgress, [0, 0.33, 0.66, 1], [0.4, 0.4, 1, 0.4])
  const rightZIndex = useTransform(scrollYProgress, [0.5, 0.66, 0.85], [10, 20, 10])
  const rightHeroOpacity = useTransform(scrollYProgress, [0.5, 0.66, 0.85], [0, 1, 0])

  // --- 4. RIGHT SIDE TEXT OPACITY MAPPING ---
  const textOpacity1 = useTransform(scrollYProgress, [0, 0.15], [1, 0])
  const textOpacity2 = useTransform(scrollYProgress, [0.25, 0.33, 0.45], [0, 1, 0])
  const textOpacity3 = useTransform(scrollYProgress, [0.55, 0.66, 0.75], [0, 1, 0])
  const textOpacity4 = useTransform(scrollYProgress, [0.85, 1], [0, 1])

  const pointerEvents = useTransform(scrollYProgress, (pos) => pos > 0.9 ? 'auto' : 'none')

  return (
    <div className="sticky top-0 h-screen overflow-hidden flex items-center justify-center">
      {/* Background Ambience */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-accent/5 rounded-full blur-[80px]"></div>
      </div>

      <div className="w-full max-w-7xl mx-auto px-4 pt-24 pb-8 relative z-10">
        <div className={`grid grid-cols-1 lg:grid-cols-2 gap-12 items-center h-full ${isRTL ? 'lg:flex-row-reverse' : ''}`}>

          {/* === LEFT COLUMN: THE DIAMOND CLUSTER === */}
          <div className="relative flex items-center justify-center h-[500px]">
            <div className="relative w-[20rem] h-[20rem] md:w-[28rem] md:h-[28rem]">

              {/* 1. MAIN DIAMOND */}
              <motion.div
                style={{ top: mainTop, left: mainLeft, scale: mainScale, zIndex: mainZIndex, opacity: mainOpacity, translateX: '-50%', translateY: '-50%' }}
                className="absolute w-64 h-64"
              >
                <DiamondLayers heroOpacity={mainHeroOpacity}>
                  <div className="flex flex-col items-center justify-center p-4 text-center">
                    <h2 className="text-3xl font-extrabold text-white mb-2 leading-none">VIP<br />ACCESS</h2>
                  </div>
                </DiamondLayers>
              </motion.div>

              {/* 2. LEFT DIAMOND */}
              <motion.div
                style={{ top: leftTop, left: leftLeft, scale: leftScale, zIndex: leftZIndex, opacity: leftOpacity, translateX: '-50%', translateY: '-50%' }}
                className="absolute w-64 h-64"
              >
                <DiamondLayers heroOpacity={leftHeroOpacity}>
                  <div className="flex flex-col items-center justify-center text-center p-4">
                    <h3 className="text-3xl font-bold text-white leading-none mb-2">{t('vip.liveSignals')}</h3>
                  </div>
                </DiamondLayers>
              </motion.div>

              {/* 3. RIGHT DIAMOND */}
              <motion.div
                style={{ top: rightTop, left: rightLeft, scale: rightScale, zIndex: rightZIndex, opacity: rightOpacity, translateX: '-50%', translateY: '-50%' }}
                className="absolute w-64 h-64"
              >
                <DiamondLayers heroOpacity={rightHeroOpacity}>
                  <div className="flex flex-col items-center justify-center text-center p-4">
                    <h3 className="text-3xl font-bold text-white leading-none mb-2">{t('vip.expertAnalysis')}</h3>
                  </div>
                </DiamondLayers>
              </motion.div>

            </div>
          </div>

          {/* === RIGHT COLUMN: THE CHANGING TEXT === */}
          <div className="relative h-[300px] flex items-center justify-center lg:justify-start">

            {/* TEXT 1: INTRO */}
            <motion.div style={{ opacity: textOpacity1 }} className="absolute inset-0 flex flex-col justify-center space-y-4">
              <div className="inline-flex items-center gap-2 text-accent font-mono text-sm tracking-widest uppercase mb-2">
                <span className="w-2 h-2 bg-accent rounded-full"></span> Step 01
              </div>
              <h2 className="text-4xl md:text-6xl font-bold text-white leading-tight">
                {t('vip.unlockTitle')}
              </h2>
              <p className="text-xl text-accent/80 leading-relaxed font-light">
                {t('vip.unlockDescription')}
              </p>
            </motion.div>

            {/* TEXT 2: SIGNALS */}
            <motion.div style={{ opacity: textOpacity2 }} className="absolute inset-0 flex flex-col justify-center space-y-4 pointer-events-none">
              <div className="inline-flex items-center gap-2 text-green-400 font-mono text-sm tracking-widest uppercase mb-2">
                <span className="w-2 h-2 bg-green-400 rounded-full"></span> Step 02
              </div>
              <h2 className="text-4xl md:text-6xl font-bold text-white leading-tight">
                {t('vip.realTimePrecision')}
              </h2>
              <p className="text-xl text-accent/80 leading-relaxed font-light">
                {t('vip.realTimePrecisionDescription')}
              </p>
            </motion.div>

            {/* TEXT 3: ANALYSIS */}
            <motion.div style={{ opacity: textOpacity3 }} className="absolute inset-0 flex flex-col justify-center space-y-4 pointer-events-none">
              <div className="inline-flex items-center gap-2 text-blue-400 font-mono text-sm tracking-widest uppercase mb-2">
                <span className="w-2 h-2 bg-blue-400 rounded-full"></span> Step 03
              </div>
              <h2 className="text-4xl md:text-6xl font-bold text-white leading-tight">
                {t('vip.expertIntelligence')}
              </h2>
              <p className="text-xl text-accent/80 leading-relaxed font-light">
                {t('vip.expertIntelligenceDescription')}
              </p>
            </motion.div>

            {/* TEXT 4: CTA */}
            <motion.div style={{ opacity: textOpacity4 }} className="absolute inset-0 flex flex-col justify-center space-y-4 pointer-events-none">
              <div className="inline-flex items-center gap-2 text-accent font-mono text-sm tracking-widest uppercase mb-2">
                <span className="w-2 h-2 bg-accent rounded-full"></span> Final Step
              </div>
              <h2 className="text-4xl md:text-6xl font-bold text-white leading-tight">
                {t('vip.startJourney')}
              </h2>
              <p className="text-xl text-accent/80 leading-relaxed font-light mb-6">
                {t('vip.startJourneyDescription')}
              </p>
              <motion.div style={{ pointerEvents }} className="pt-4">
                <button className="btn-primary text-xl font-bold px-10 py-4 shadow-xl hover:scale-105 transition-transform rounded-xl">
                  {t('vip.subscribe')}
                </button>
              </motion.div>
            </motion.div>

          </div>

        </div>
      </div>
    </div>
  )
}

// Main component - ALWAYS renders the section with ref to prevent hydration issues
export default function VipTradingSection({ isMember, joinedVip }: VipTradingSectionProps) {
  const hasAccess = isMember || joinedVip || false
  const { t, isRTL } = useLanguage()
  const [latestSignal, setLatestSignal] = useState<VipDashboardPreview | null>(null)
  const [expertInsight, setExpertInsight] = useState<VipDashboardPreview | null>(null)
  const [isLoadingPreviews, setIsLoadingPreviews] = useState(true)
  
  // Use callback ref to reliably detect when element is attached
  const [containerElement, setContainerElement] = useState<HTMLElement | null>(null)
  const containerRef = useRef<HTMLElement | null>(null)
  
  // Callback ref that updates both the ref and state
  const setRef = useCallback((node: HTMLElement | null) => {
    containerRef.current = node
    setContainerElement(node)
  }, [])

  // Load VIP dashboard previews
  useEffect(() => {
    if (hasAccess) {
      loadPreviews()
    }
  }, [hasAccess])

  const loadPreviews = async () => {
    setIsLoadingPreviews(true)
    try {
      const previews = await getVipDashboardPreviews()
      // Get the first active preview of each type
      const signal = previews.find(p => p.type === 'latest_signal' && p.is_active)
      const insight = previews.find(p => p.type === 'expert_insight' && p.is_active)
      setLatestSignal(signal || null)
      setExpertInsight(insight || null)
    } catch (error) {
      console.error('Error loading VIP dashboard previews:', error)
    } finally {
      setIsLoadingPreviews(false)
    }
  }

  // ALWAYS render the same section structure - prevents ref issues on auth state changes
  return (
    <section
      ref={setRef}
      className={hasAccess ? "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20" : "relative h-[500vh]"}
    >
      {hasAccess ? (
        // Inside your hasAccess ? (...) block:

        <div className="relative overflow-hidden bg-gradient-to-br from-secondary-surface to-primary-dark p-8 md:p-12 border border-accent/30 rounded-3xl shadow-2xl">
          {/* Background Decoration */}
          <div className="absolute top-0 right-0 -mt-20 -mr-20 w-64 h-64 bg-accent/10 rounded-full blur-3xl pointer-events-none"></div>

          <div className="relative z-10 flex flex-col lg:flex-row gap-10 items-center">

            {/* Left: Quick Stats / Welcome */}
            <div className="flex-1 text-center lg:text-left">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-accent/10 border border-accent/20 text-accent text-xs font-bold uppercase tracking-widest mb-4">
                <span className="relative flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-accent opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-accent"></span>
                </span>
                {t('vip.liveAccessActive')}
              </div>
              <h2 className="text-3xl md:text-5xl font-bold text-white mb-4">
                {t('vip.welcomeBack')}, <span className="text-accent">{t('vip.trader')}</span>
              </h2>
              <p className="text-accent/70 text-lg max-w-xl mb-8">
                {t('vip.dashboardIntro')}
              </p>

              <div className="flex flex-wrap gap-4 justify-center lg:justify-start">
                <button className="bg-accent text-primary-dark font-bold px-8 py-3 rounded-xl hover:bg-white transition-colors">
                  {t('vip.viewSignals')}
                </button>
                <button className="bg-secondary-surface border border-accent/30 text-white font-bold px-8 py-3 rounded-xl hover:bg-accent/10 transition-colors">
                  {t('vip.marketAnalysis')}
                </button>
              </div>
            </div>

            {/* Right: Feature Preview Cards */}
            <div className="w-full lg:w-1/3 grid grid-cols-1 gap-4">
              {/* Latest Signal Card */}
              {isLoadingPreviews ? (
                <div className="bg-primary-dark/50 border border-white/5 p-5 rounded-2xl backdrop-blur-sm">
                  <div className="text-accent/50 text-sm">Loading...</div>
                </div>
              ) : latestSignal ? (
                <div className="bg-primary-dark/50 border border-white/5 p-5 rounded-2xl backdrop-blur-sm">
                  <p className="text-xs text-accent/50 uppercase mb-1 font-mono">{t('vip.latestSignal')}</p>
                  <div className="flex justify-between items-center">
                    <span className="text-white font-bold text-lg">{latestSignal.symbol}</span>
                    <span className={`font-mono font-bold ${latestSignal.action === 'BUY' ? 'text-green-400' : 'text-red-400'}`}>
                      {latestSignal.action} @ {latestSignal.price}
                    </span>
                  </div>
                </div>
              ) : (
                <div className="bg-primary-dark/50 border border-white/5 p-5 rounded-2xl backdrop-blur-sm">
                  <p className="text-xs text-accent/50 uppercase mb-1 font-mono">{t('vip.latestSignal')}</p>
                  <p className="text-accent/50 text-sm">No signal available</p>
                </div>
              )}

              {/* Expert Insight Card */}
              {isLoadingPreviews ? (
                <div className="bg-primary-dark/50 border border-white/5 p-5 rounded-2xl backdrop-blur-sm">
                  <div className="text-accent/50 text-sm">Loading...</div>
                </div>
              ) : expertInsight ? (
                <div className="bg-primary-dark/50 border border-white/5 p-5 rounded-2xl backdrop-blur-sm">
                  <p className="text-xs text-accent/50 uppercase mb-1 font-mono">{t('vip.expertInsight')}</p>
                  <p className="text-white text-sm line-clamp-1">
                    {isRTL ? expertInsight.text_ar : expertInsight.text_en}
                  </p>
                </div>
              ) : (
                <div className="bg-primary-dark/50 border border-white/5 p-5 rounded-2xl backdrop-blur-sm">
                  <p className="text-xs text-accent/50 uppercase mb-1 font-mono">{t('vip.expertInsight')}</p>
                  <p className="text-accent/50 text-sm">No insight available</p>
                </div>
              )}
            </div>

          </div>
        </div>
      ) : (
        // NON-VIP SCROLLYTELLING VIEW
        // Only render scroll content when element is attached (containerElement !== null)
        containerElement ? (
          <ScrollAnimatedContent
            containerRef={containerRef as RefObject<HTMLElement>}
            t={t}
            isRTL={isRTL}
          />
        ) : (
          // Placeholder while waiting for ref attachment
          <div className="sticky top-0 h-screen overflow-hidden flex items-center justify-center">
            <div className="text-accent/50">Loading...</div>
          </div>
        )
      )}
    </section>
  )
}
