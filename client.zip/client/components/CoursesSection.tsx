'use client'

import { useRef, useState, useEffect, useCallback, RefObject } from 'react'
import { motion, useScroll, useTransform, useSpring } from 'framer-motion'
import { useLanguage } from '@/contexts/LanguageContext'

interface CoursesSectionProps {
  subscribedToCourses: boolean
}

// Inner component that uses useScroll - only rendered when container element is ready
function ScrollAnimatedCourses({ 
  containerRef, 
  features,
  t,
  isRTL 
}: { 
  containerRef: RefObject<HTMLElement>
  features: Array<{ id: number; title: string; subtitle: string; description: string }>
  t: (key: string) => string
  isRTL: boolean 
}) {
  // Track scroll progress - containerRef.current is guaranteed to exist here
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start start", "end end"]
  })

  // Smooth out the progress bar filling
  const smoothProgress = useSpring(scrollYProgress, { stiffness: 100, damping: 30, restDelta: 0.001 })

  const [activeIndex, setActiveIndex] = useState(0)

  useEffect(() => {
    return scrollYProgress.on("change", (latest) => {
      // 0, 1, 2, 3 = Features
      // 4 = Final Button Step
      const totalSteps = features.length + 1
      const newIndex = Math.min(
        Math.floor(latest * totalSteps), 
        totalSteps - 1
      )
      setActiveIndex(newIndex)
    })
  }, [scrollYProgress, features.length])

  // Progress bar height transform
  const progressHeight = useTransform(smoothProgress, [0, 1], ["0%", "100%"])

  return (
    <div className="sticky top-0 h-screen flex flex-col justify-center overflow-hidden">
      
      {/* Background Ambience */}
      <div className={`absolute top-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-accent/5 blur-[120px] rounded-full pointer-events-none ${isRTL ? 'left-0' : 'right-0'}`}></div>

      <div className="max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-12 gap-8 items-center relative z-10">
         
         {/* === LEFT COLUMN: THE TIMELINE === */}
         <div className={`col-span-2 flex flex-col items-center relative h-[500px] ${isRTL ? 'order-2' : ''}`}>
             
             {/* Vertical Line (Background) */}
             <div className="absolute top-0 bottom-0 w-[1px] bg-white/5"></div>
             
             {/* Vertical Line (Foreground) */}
             <motion.div 
               style={{ height: progressHeight }}
               className="absolute top-0 w-[2px] bg-accent shadow-[0_0_20px_rgba(var(--accent-rgb),1)] origin-top z-0"
             ></motion.div>

             {/* The Diamonds */}
             <div className="flex flex-col justify-between h-full w-full relative z-10">
                 {features.map((feature, index) => (
                     <TimelineNode 
                        key={feature.id} 
                        index={index} 
                        activeIndex={activeIndex} 
                        isRTL={isRTL}
                     />
                 ))}
             </div>
         </div>


         {/* === RIGHT COLUMN: THE CONTENT === */}
         <div className={`col-span-10 pl-8 md:pl-12 flex flex-col justify-center h-[400px] ${isRTL ? 'order-1 pr-8 md:pr-12 pl-0 text-right' : ''}`}>
             
             <div className="relative w-full h-full flex flex-col justify-center">
                 
                 {/* 1. ANIMATED TEXT BLOCKS */}
                 {features.map((feature, index) => (
                     <ContentCard 
                        key={feature.id} 
                        feature={feature} 
                        isActive={activeIndex === index} 
                     />
                 ))}

                 {/* 2. FINAL CTA BUTTON - ONLY APPEARS AT STEP 5 */}
                 <motion.div 
                      initial={{ opacity: 0, scale: 0.9 }}
                      animate={{ 
                          opacity: activeIndex === features.length ? 1 : 0,
                          scale: activeIndex === features.length ? 1 : 0.9,
                          pointerEvents: activeIndex === features.length ? 'auto' : 'none'
                      }}
                      transition={{ duration: 0.6, ease: "easeOut" }}
                      className="absolute inset-0 flex flex-col items-start justify-center"
                 >
                      <h3 className="text-4xl md:text-5xl font-bold text-white mb-6">
                          {t('courses.readyToStart')}
                      </h3>
                      <p className="text-xl text-accent/80 mb-8 max-w-xl">
                          {t('courses.finalDescription')}
                      </p>
                      <button className="btn-primary text-xl font-bold px-12 py-5 shadow-[0_0_40px_rgba(var(--accent-rgb),0.4)] hover:scale-105 transition-transform rounded-xl">
                          {t('courses.subscribeNow')}
                      </button>
                 </motion.div>

             </div>
         </div>

      </div>
    </div>
  )
}

// Main component - ALWAYS renders the section with ref to prevent hydration issues
export default function CoursesSection({ subscribedToCourses }: CoursesSectionProps) {
  const { t, isRTL } = useLanguage()
  
  // Use callback ref to reliably detect when element is attached
  const [containerElement, setContainerElement] = useState<HTMLElement | null>(null)
  const containerRef = useRef<HTMLElement | null>(null)
  
  // Callback ref that updates both the ref and state
  const setRef = useCallback((node: HTMLElement | null) => {
    containerRef.current = node
    setContainerElement(node)
  }, [])
  
  // === CONTENT DATA ===
  const features = [
    {
      id: 1,
      title: t('courses.feature1.title'),
      subtitle: t('courses.feature1.subtitle'),
      description: t('courses.feature1.description'),
    },
    {
      id: 2,
      title: t('courses.feature2.title'),
      subtitle: t('courses.feature2.subtitle'),
      description: t('courses.feature2.description'),
    },
    {
      id: 3,
      title: t('courses.feature3.title'),
      subtitle: t('courses.feature3.subtitle'),
      description: t('courses.feature3.description'),
    },
    {
      id: 4,
      title: t('courses.feature4.title'),
      subtitle: t('courses.feature4.subtitle'),
      description: t('courses.feature4.description'),
    }
  ]

  // ALWAYS render the same section structure - prevents ref issues on auth state changes
  return (
    <section 
      ref={setRef} 
      id="courses" 
      className={subscribedToCourses ? "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20" : "relative h-[500vh]"}
    >
      {subscribedToCourses ? (
        // SUBSCRIBED VIEW - simple view without scroll animations
        <>
          <div className="text-center mb-10">
            <h2 className="text-3xl font-bold text-base-white">{t('courses.title')}</h2>
          </div>
          <div className="relative group w-full max-w-5xl mx-auto border border-white/10 bg-primary-dark p-1">
            <div className="aspect-video bg-black/40 flex items-center justify-center text-accent">
              {t('courses.patreonPlaceholder')}
            </div>
          </div>
        </>
      ) : (
        // NON-SUBSCRIBED SCROLL TIMELINE VIEW
        // Only render scroll content when element is attached (containerElement !== null)
        containerElement ? (
          <ScrollAnimatedCourses 
            containerRef={containerRef as RefObject<HTMLElement>} 
            features={features}
            t={t} 
            isRTL={isRTL} 
          />
        ) : (
          // Placeholder while waiting for ref attachment
          <div className="sticky top-0 h-screen flex items-center justify-center">
            <div className="text-accent/50">Loading...</div>
          </div>
        )
      )}
    </section>
  )
}


// === SUB-COMPONENT: TIMELINE NODE ===
function TimelineNode({ index, activeIndex, isRTL }: { index: number, activeIndex: number, isRTL: boolean }) {
    const isActive = index === activeIndex
    const isPast = index < activeIndex

    return (
        <div className="relative flex items-center justify-center w-full">
            
            {/* The Diamond Shape */}
            <motion.div 
                animate={{ 
                    scale: isActive ? 1.8 : 1, 
                    borderColor: (isActive || isPast) ? 'rgba(var(--accent-rgb), 1)' : 'rgba(255,255,255, 0.1)',
                    backgroundColor: (isActive || isPast) ? 'rgba(var(--accent-rgb), 1)' : 'rgba(15, 23, 42, 1)', 
                    boxShadow: isActive ? '0 0 40px rgba(var(--accent-rgb), 0.6)' : 'none'
                }}
                transition={{ duration: 0.4 }}
                className="w-5 h-5 rotate-45 border-2 z-10 flex items-center justify-center backdrop-blur-sm"
            >
                <motion.div 
                    animate={{ opacity: isActive ? 1 : 0 }}
                    className="w-2 h-2 bg-white" 
                ></motion.div>
            </motion.div>
            
            {/* Connector Line */}
             <motion.div 
                animate={{ 
                    width: isActive ? 40 : 0, 
                    opacity: isActive ? 1 : 0
                }}
                className={`absolute top-1/2 -translate-y-1/2 h-[1px] bg-accent ${isRTL ? 'right-full' : 'left-full'}`}
             ></motion.div>

        </div>
    )
}


// === SUB-COMPONENT: CONTENT CARD ===
function ContentCard({ feature, isActive }: { feature: any, isActive: boolean }) {
    return (
        <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ 
                opacity: isActive ? 1 : 0, 
                y: isActive ? 0 : 30,
                pointerEvents: isActive ? 'auto' : 'none'
            }}
            transition={{ duration: 0.5, ease: "easeOut" }}
            className="absolute top-0 left-0 w-full h-full flex flex-col justify-center"
        >
            <h4 className="text-accent font-mono text-sm md:text-base uppercase tracking-[0.3em] mb-4 font-bold">
                {feature.subtitle}
            </h4>
            
            <h3 className="text-5xl md:text-7xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-white via-white to-accent/50 mb-8 leading-tight tracking-tight">
                {feature.title}
            </h3>
            
            <div className="w-24 h-1 bg-accent mb-8"></div>
            
            <p className="text-2xl md:text-3xl text-accent/80 leading-relaxed font-light max-w-3xl">
                {feature.description}
            </p>
        </motion.div>
    )
}
