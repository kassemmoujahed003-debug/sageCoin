'use client'

import { useState } from 'react'
import { useLanguage } from '@/contexts/LanguageContext'
import ChangePasswordForm from '@/components/forms/ChangePasswordForm'
import WithdrawalForm from '@/components/forms/WithdrawalForm'
import DepositForm from '@/components/forms/DepositForm'

interface UserDashboardProps {
  currentLeverage: number
  currentLotSize: number
}

export default function UserDashboard({ currentLeverage, currentLotSize }: UserDashboardProps) {
  const { t, isRTL } = useLanguage()
  const [showChangePassword, setShowChangePassword] = useState(false)
  const [showWithdrawal, setShowWithdrawal] = useState(false)
  const [showDeposit, setShowDeposit] = useState(false)

  const handleChangePassword = () => {
    setShowChangePassword(true)
  }

  const handleWithdrawal = () => {
    setShowWithdrawal(true)
  }

  const handleDeposit = () => {
    setShowDeposit(true)
  }

  return (
    <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      {/* Settings Bar */}
      <div className="bg-secondary-surface border border-accent rounded-2xl p-6 mb-12">
        <h2 className="text-2xl font-bold text-base-white mb-6">{t('dashboard.settings')}</h2>
        <div className="grid md:grid-cols-3 gap-4">
          <button
            onClick={handleChangePassword}
            className={`btn-secondary ${isRTL ? 'text-right' : 'text-left'} px-6 py-4 flex items-center ${isRTL ? 'flex-row-reverse' : ''} justify-between hover:scale-[1.02] transition-transform`}
          >
            <span className="text-base-white font-semibold">{t('dashboard.changePassword')}</span>
            <svg
              className={`w-5 h-5 text-accent ${isRTL ? 'rotate-180' : ''}`}
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M9 5l7 7-7 7"
              />
            </svg>
          </button>

          <button
            onClick={handleWithdrawal}
            className={`btn-secondary ${isRTL ? 'text-right' : 'text-left'} px-6 py-4 flex items-center ${isRTL ? 'flex-row-reverse' : ''} justify-between hover:scale-[1.02] transition-transform`}
          >
            <span className="text-base-white font-semibold">Withdrawal</span>
            <svg
              className={`w-5 h-5 text-accent ${isRTL ? 'rotate-180' : ''}`}
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M9 5l7 7-7 7"
              />
            </svg>
          </button>

          <button
            onClick={handleDeposit}
            className={`btn-secondary ${isRTL ? 'text-right' : 'text-left'} px-6 py-4 flex items-center ${isRTL ? 'flex-row-reverse' : ''} justify-between hover:scale-[1.02] transition-transform`}
          >
            <span className="text-base-white font-semibold">Deposit</span>
            <svg
              className={`w-5 h-5 text-accent ${isRTL ? 'rotate-180' : ''}`}
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M9 5l7 7-7 7"
              />
            </svg>
          </button>
        </div>
      </div>

      {/* Form Modals */}
      <ChangePasswordForm
        isOpen={showChangePassword}
        onClose={() => setShowChangePassword(false)}
      />
      <WithdrawalForm
        isOpen={showWithdrawal}
        onClose={() => setShowWithdrawal(false)}
      />
      <DepositForm
        isOpen={showDeposit}
        onClose={() => setShowDeposit(false)}
      />

      {/* Market Analysis Section */}
      {/* <div>
        <h2 className="text-3xl md:text-4xl font-bold text-base-white mb-8">{t('dashboard.marketAnalysis')}</h2>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          <div className="col-span-full text-center py-12 text-accent/60">
            <p>{t('dashboard.analysisDescription')}</p>
            <p className="text-sm mt-2">Market analysis data will be displayed here</p>
          </div>
        </div>
      </div> */}
    </section>
  )
}

