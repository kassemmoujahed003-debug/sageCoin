'use client'

import { useState, useEffect } from 'react'
import { useLanguage } from '@/contexts/LanguageContext'
import { getMarketAnalysisSections } from '@/services/marketAnalysisService'
import { MarketAnalysisSection as MarketAnalysisSectionType } from '@/types/database'

export default function MarketAnalysisSection() {
  const { language, isRTL } = useLanguage()
  const [sections, setSections] = useState<MarketAnalysisSectionType[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    loadSections()
  }, [])

  const loadSections = async () => {
    setIsLoading(true)
    setError(null)
    try {
      const fetchedSections = await getMarketAnalysisSections()
      console.log('Loaded sections:', fetchedSections) // Debug log
      setSections(fetchedSections)
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load market analysis')
      console.error('Error loading market analysis sections:', err)
    } finally {
      setIsLoading(false)
    }
  }

  if (isLoading) {
    return (
      <section className="py-16 bg-primary-dark">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center text-accent">Loading market analysis...</div>
        </div>
      </section>
    )
  }

  if (error || sections.length === 0) {
    if (error) {
      console.error('Market Analysis Error:', error)
    }
    if (sections.length === 0) {
      console.log('No market analysis sections found')
    }
    return null // Don't show anything if there's an error or no sections
  }

  return (
    <section className="py-16 bg-primary-dark">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Title */}
        <div className={`mb-8 ${isRTL ? 'text-right' : 'text-left'}`}>
          <h2 className="text-3xl md:text-4xl font-bold text-base-white mb-2">
            {language === 'ar' ? 'تحليل السوق' : 'Market Analysis'}
          </h2>
        </div>

        {/* Horizontal Scroll Container */}
        <div className="relative">
          {/* Scroll Container */}
          <div 
            className={`flex gap-6 overflow-x-auto pb-6 scrollbar-hide ${isRTL ? 'flex-row-reverse' : ''}`}
            style={{
              scrollSnapType: 'x mandatory',
              WebkitOverflowScrolling: 'touch',
            }}
          >
            {sections.map((section, index) => {
              const title = language === 'ar' ? section.title_ar : section.title_en
              const description = language === 'ar' ? section.description_ar : section.description_en

              return (
                <div
                  key={section.id}
                  className="flex-shrink-0 w-full sm:w-[90%] md:w-[80%] lg:w-[70%] xl:w-[60%] snap-start"
                  style={{ minWidth: 'min(90vw, 600px)' }}
                >
                  <div className="bg-secondary-surface border border-accent border-opacity-30 rounded-lg overflow-hidden h-full flex flex-col">
                    {/* Image */}
                    <div className="w-full h-64 md:h-80 lg:h-96 flex-shrink-0">
                      <img
                        src={section.image_url}
                        alt={title}
                        className="w-full h-full object-cover"
                      />
                    </div>

                    {/* Text Content */}
                    <div className={`p-6 flex-1 flex flex-col ${isRTL ? 'text-right' : 'text-left'}`}>
                      <h3 className="text-2xl md:text-3xl font-bold text-base-white mb-4">
                        {title}
                      </h3>
                      <p className="text-base md:text-lg text-accent leading-relaxed whitespace-pre-line flex-1">
                        {description}
                      </p>
                    </div>
                  </div>
                </div>
              )
            })}
          </div>

          {/* Scroll Indicator */}
          {sections.length > 1 && (
            <div className={`flex justify-center mt-4 gap-2 ${isRTL ? 'flex-row-reverse' : ''}`}>
              {sections.map((_, index) => (
                <div
                  key={index}
                  className="w-2 h-2 rounded-full bg-accent opacity-30"
                />
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Custom Scrollbar Styles */}
      <style jsx>{`
        .scrollbar-hide::-webkit-scrollbar {
          height: 8px;
        }
        .scrollbar-hide::-webkit-scrollbar-track {
          background: rgba(255, 255, 255, 0.05);
          border-radius: 4px;
        }
        .scrollbar-hide::-webkit-scrollbar-thumb {
          background: rgba(var(--accent-rgb, 255, 200, 0), 0.5);
          border-radius: 4px;
        }
        .scrollbar-hide::-webkit-scrollbar-thumb:hover {
          background: rgba(var(--accent-rgb, 255, 200, 0), 0.7);
        }
      `}</style>
    </section>
  )
}

